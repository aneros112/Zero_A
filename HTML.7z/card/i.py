import random
import json
import csv
import time
from datetime import datetime, timedelta
import os
import hashlib
import math
from collections import Counter

class AdvancedCreditCardGenerator:
    def __init__(self):
        # BINs حقيقية بناءً على إحصائيات فعلية
        self.bin_databases = {
            'visa': {
                'ranges': [
                    ('400000', '499999'),  # نطاق فيزا الأساسي
                    ('400000000000', '499999999999')
                ],
                'lengths': [13, 16],
                'countries': {
                    'US': ['400000', '401200', '402400', '403000', '404000'],
                    'GB': ['400005', '400006', '400007', '400008'],
                    'AE': ['450875', '450876', '450877', '450878'],
                    'SA': ['403024', '403025', '404825', '409201'],
                    'EG': ['421345', '421346', '421347']
                }
            },
            'mastercard': {
                'ranges': [
                    ('222100', '272099'),  # نطاق ماستركارد الجديد
                    ('510000', '559999'),   # نطاق ماستركارد التقليدي
                    ('222100000000', '272099999999'),
                    ('5100000000000000', '5599999999999999')
                ],
                'lengths': [16],
                'countries': {
                    'US': ['510000', '520000', '530000', '540000', '550000'],
                    'GB': ['510100', '510200', '510300'],
                    'AE': ['510400', '510500', '510600'],
                    'SA': ['510700', '510800', '510900']
                }
            },
            'amex': {
                'ranges': [
                    ('340000', '349999'),  # أمريكان إكسبريس
                    ('370000', '379999'),
                    ('340000000000000', '349999999999999'),
                    ('370000000000000', '379999999999999')
                ],
                'lengths': [15],
                'countries': {
                    'US': ['340000', '370000'],
                    'GB': ['340100', '370100'],
                    'AE': ['340200', '370200']
                }
            },
            'discover': {
                'ranges': [
                    ('601100', '601109'),  # ديسكفر
                    ('644000', '659999'),
                    ('6011000000000000', '6011099999999999'),
                    ('6440000000000000', '6599999999999999')
                ],
                'lengths': [16],
                'countries': {
                    'US': ['601100', '601101', '601102'],
                    'GB': ['601103', '601104'],
                    'AE': ['601105', '601106']
                }
            }
        }
        
        self.country_codes = ['US', 'GB', 'AE', 'SA', 'EG', 'QA', 'KW', 'BH']
        self.card_types = list(self.bin_databases.keys())
        
        # إحصائيات حقيقية لتوزيع أنواع البطاقات
        self.card_type_distribution = {
            'visa': 0.45,       # 45%
            'mastercard': 0.35, # 35%
            'amex': 0.10,       # 10%
            'discover': 0.10    # 10%
        }

    def luhn_checksum(self, number):
        """خوارزمية Luhn المحسنة للتحقق من صحة البطاقة"""
        def digits_of(n):
            return [int(d) for d in str(n)]
        
        digits = digits_of(number)
        odd_digits = digits[-1::-2]
        even_digits = digits[-2::-2]
        checksum = sum(odd_digits)
        
        for d in even_digits:
            checksum += sum(digits_of(d * 2))
            
        return checksum % 10

    def calculate_luhn_digit(self, number):
        """حساب رقم التحقق Luhn بدقة عالية"""
        total = self.luhn_checksum(number + '0')
        return (10 - total) % 10

    def generate_valid_bin(self, card_type, country=None):
        """توليد BIN صالح بناءً على النوع والبلد"""
        if card_type not in self.bin_databases:
            card_type = random.choices(
                list(self.card_type_distribution.keys()),
                weights=list(self.card_type_distribution.values()),
                k=1
            )[0]
        
        country_data = self.bin_databases[card_type]['countries']
        
        if country and country in country_data:
            bin_prefix = random.choice(country_data[country])
        else:
            # اختيار عشوائي من جميع البلدان
            all_bins = []
            for bins in country_data.values():
                all_bins.extend(bins)
            bin_prefix = random.choice(all_bins)
        
        return bin_prefix

    def generate_card_number(self, card_type, country=None):
        """توليد رقم بطاقة صالح باستخدام خوارزميات واقعية"""
        bin_prefix = self.generate_valid_bin(card_type, country)
        card_length = random.choice(self.bin_databases[card_type]['lengths'])
        
        # عدد الأرقام المتبقية بعد BIN
        remaining_length = card_length - len(bin_prefix) - 1  # -1 لرقم التحقق
        
        # توليد الأرقام العشوائية المتبقية
        random_digits = ''.join(str(random.randint(0, 9)) for _ in range(remaining_length))
        partial_number = bin_prefix + random_digits
        
        # حساب رقم التحقق
        check_digit = self.calculate_luhn_digit(partial_number)
        full_number = partial_number + str(check_digit)
        
        return full_number

    def validate_card(self, card_number):
        """التحقق من صحة البطاقة باستخدام Luhn"""
        return self.luhn_checksum(card_number) == 0

    def generate_expiry_date(self, validity_years=1, validity_months=36):
        """توليد تاريخ انتهاء صالح بناءً على إحصائيات حقيقية"""
        current_date = datetime.now()
        
        # توزيع واقعي لفترات الصلاحية
        months = random.randint(validity_years * 12, validity_months)
        expiry_date = current_date + timedelta(days=30 * months)
        
        return expiry_date.strftime('%m/%y')

    def generate_cvv(self, card_type):
        """توليد CVV بناءً على نوع البطاقة"""
        if card_type == 'amex':
            return str(random.randint(1000, 9999))  # 4 أرقام لأميكس
        else:
            return str(random.randint(100, 999))    # 3 أرقام للباقي

    def generate_cardholder_name(self, country):
        """توليد أسماء واقعية بناءً على البلد"""
        arabic_names = {
            'first': ['محمد', 'أحمد', 'علي', 'عمر', 'خالد', 'محمود', 'حسن', 'حسين', 'إبراهيم', 'يوسف'],
            'last': ['السهلي', 'الغنيم', 'العتيبي', 'الحربي', 'الزهراني', 'الغامدي', 'القحطاني', 'الشمراني']
        }
        
        western_names = {
            'first': ['John', 'David', 'Michael', 'Robert', 'James', 'William', 'Richard', 'Joseph'],
            'last': ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Wilson']
        }
        
        if country in ['SA', 'AE', 'EG', 'QA', 'KW', 'BH']:
            first = random.choice(arabic_names['first'])
            last = random.choice(arabic_names['last'])
        else:
            first = random.choice(western_names['first'])
            last = random.choice(western_names['last'])
        
        return f"{first} {last}"

    def generate_address(self, country):
        """توليد عناوين واقعية بناءً على البلد"""
        addresses = {
            'SA': [
                {'street': 'King Fahd Road', 'city': 'Riyadh', 'zip': '11564'},
                {'street': 'Tahlia Street', 'city': 'Jeddah', 'zip': '21432'},
                {'street': 'Prince Sultan St', 'city': 'Dammam', 'zip': '31451'}
            ],
            'AE': [
                {'street': 'Sheikh Zayed Road', 'city': 'Dubai', 'zip': '12345'},
                {'street': 'Corniche Road', 'city': 'Abu Dhabi', 'zip': '54321'},
                {'street': 'Al Maryah Island', 'city': 'Abu Dhabi', 'zip': '67890'}
            ],
            'US': [
                {'street': 'Main Street', 'city': 'New York', 'zip': '10001'},
                {'street': 'Broadway', 'city': 'Los Angeles', 'zip': '90001'},
                {'street': 'Michigan Avenue', 'city': 'Chicago', 'zip': '60601'}
            ],
            'GB': [
                {'street': 'Oxford Street', 'city': 'London', 'zip': 'W1A 1AB'},
                {'street': 'High Street', 'city': 'Manchester', 'zip': 'M1 1AA'},
                {'street': 'Princes Street', 'city': 'Edinburgh', 'zip': 'EH2 2AN'}
            ]
        }
        
        if country in addresses:
            return random.choice(addresses[country])
        else:
            return {'street': 'Main Street', 'city': 'Capital', 'zip': '10001'}

    def generate_phone_number(self, country):
        """توليد أرقام هواتف واقعية"""
        country_codes = {
            'SA': '+9665', 'AE': '+9715', 'US': '+1', 'GB': '+44',
            'EG': '+201', 'QA': '+974', 'KW': '+965', 'BH': '+973'
        }
        
        prefix = country_codes.get(country, '+1')
        number = ''.join(str(random.randint(0, 9)) for _ in range(9))
        return prefix + number

    def generate_email(self, name):
        """توليد بريد إلكتروني واقعي"""
        domains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'icloud.com']
        name_part = name.lower().replace(' ', '.')
        return f"{name_part}@{random.choice(domains)}"

    def generate_single_card(self, country=None):
        """توليد بطاقة واحدة كاملة بجميع البيانات"""
        if not country:
            country = random.choice(self.country_codes)
        
        # اختيار نوع البطاقة بناءً على التوزيع الإحصائي
        card_type = random.choices(
            list(self.card_type_distribution.keys()),
            weights=list(self.card_type_distribution.values()),
            k=1
        )[0]
        
        card_number = self.generate_card_number(card_type, country)
        
        # التأكد من صحة البطاقة
        while not self.validate_card(card_number):
            card_number = self.generate_card_number(card_type, country)
        
        cardholder_name = self.generate_cardholder_name(country)
        
        card_data = {
            'card_number': self.format_card_number(card_number),
            'raw_number': card_number,
            'expiry_date': self.generate_expiry_date(),
            'cvv': self.generate_cvv(card_type),
            'card_type': card_type.upper(),
            'cardholder_name': cardholder_name,
            'address': self.generate_address(country),
            'phone': self.generate_phone_number(country),
            'email': self.generate_email(cardholder_name),
            'country': country,
            'valid': self.validate_card(card_number),
            'generation_timestamp': datetime.now().isoformat(),
            'bin': card_number[:6],
            'last_4': card_number[-4:]
        }
        
        return card_data

    def format_card_number(self, card_number):
        """تنسيق رقم البطاقة بشكل مقروء"""
        return ' '.join([card_number[i:i+4] for i in range(0, len(card_number), 4)])

    def generate_bulk_cards(self, count=1000, country=None, output_format='json'):
        """توليد مجموعة كبيرة من البطاقات وحفظها في ملف"""
        cards = []
        start_time = time.time()
        
        print(f"🔄 Generating {count} credit cards...")
        
        for i in range(count):
            if (i + 1) % 100 == 0:
                print(f"📊 Generated {i + 1}/{count} cards...")
            
            card = self.generate_single_card(country)
            cards.append(card)
            
            # إضافة تأخير بسيط لتجنب الأنماط المتوقعة
            time.sleep(0.001)
        
        # حفظ البطاقات في ملف
        filename = self.save_cards_to_file(cards, output_format)
        
        end_time = time.time()
        print(f"✅ Successfully generated {count} cards in {end_time - start_time:.2f} seconds")
        print(f"💾 Saved to: {filename}")
        
        return cards

    def save_cards_to_file(self, cards, format_type='json'):
        """حفظ البطاقات في ملف بالصيغة المطلوبة"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"credit_cards_{timestamp}.{format_type}"
        
        if format_type == 'json':
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(cards, f, indent=2, ensure_ascii=False)
        
        elif format_type == 'csv':
            with open(filename, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                # كتابة Header
                writer.writerow([
                    'Card Number', 'Expiry Date', 'CVV', 'Type', 
                    'Cardholder Name', 'Country', 'Phone', 'Email',
                    'Street', 'City', 'ZIP Code', 'BIN', 'Last 4'
                ])
                
                for card in cards:
                    writer.writerow([
                        card['card_number'],
                        card['expiry_date'],
                        card['cvv'],
                        card['card_type'],
                        card['cardholder_name'],
                        card['country'],
                        card['phone'],
                        card['email'],
                        card['address']['street'],
                        card['address']['city'],
                        card['address']['zip'],
                        card['bin'],
                        card['last_4']
                    ])
        
        elif format_type == 'txt':
            with open(filename, 'w', encoding='utf-8') as f:
                for i, card in enumerate(cards, 1):
                    f.write(f"Card #{i}:\n")
                    f.write(f"Number: {card['card_number']}\n")
                    f.write(f"Expiry: {card['expiry_date']}\n")
                    f.write(f"CVV: {card['cvv']}\n")
                    f.write(f"Type: {card['card_type']}\n")
                    f.write(f"Name: {card['cardholder_name']}\n")
                    f.write(f"Country: {card['country']}\n")
                    f.write(f"Phone: {card['phone']}\n")
                    f.write(f"Email: {card['email']}\n")
                    f.write(f"Address: {card['address']['street']}, {card['address']['city']} {card['address']['zip']}\n")
                    f.write(f"BIN: {card['bin']}\n")
                    f.write(f"Last 4: {card['last_4']}\n")
                    f.write("-" * 50 + "\n\n")
        
        return filename

    def analyze_generated_cards(self, cards):
        """تحليل إحصائي للبطاقات المُنشأة"""
        print("\n📈 Statistical Analysis:")
        print("=" * 50)
        
        # تحليل توزيع أنواع البطاقات
        card_types = [card['card_type'] for card in cards]
        type_count = Counter(card_types)
        print("Card Type Distribution:")
        for card_type, count in type_count.items():
            percentage = (count / len(cards)) * 100
            print(f"  {card_type}: {count} cards ({percentage:.1f}%)")
        
        # تحليل توزيع البلدان
        countries = [card['country'] for card in cards]
        country_count = Counter(countries)
        print("\nCountry Distribution:")
        for country, count in country_count.items():
            percentage = (count / len(cards)) * 100
            print(f"  {country}: {count} cards ({percentage:.1f}%)")
        
        # تحليل BINs
        bins = [card['bin'] for card in cards]
        bin_count = Counter(bins)
        print(f"\nUnique BINs: {len(bin_count)}")
        
        # التحقق من الصحة
        valid_cards = sum(1 for card in cards if card['valid'])
        print(f"Valid Cards: {valid_cards}/{len(cards)} ({valid_cards/len(cards)*100:.1f}%)")

# مثال للاستخدام
if __name__ == "__main__":
    generator = AdvancedCreditCardGenerator()
    
    print("🎯 Advanced Credit Card Generator")
    print("=" * 60)
    
    # توليد 1000 بطاقة وحفظها في ملف JSON
    cards = generator.generate_bulk_cards(
        count=1000,
        country=None,  # None لخلط جميع البلدان
        output_format='json'  # 'json', 'csv', أو 'txt'
    )
    
    # تحليل إحصائي
    generator.analyze_generated_cards(cards)
    
    print("\n" + "=" * 60)
    print("⚠️  Important Notice:")
    print("This tool is for educational and testing purposes only.")
    print("Generated cards should not be used for illegal activities.")
    print("Always comply with local laws and regulations.")

# وظائف إضافية للتحقق والتحليل
class CardValidatorPlus:
    def __init__(self):
        self.generator = AdvancedCreditCardGenerator()
    
    def validate_external_card(self, card_number):
        """محاكاة التحقق من البطاقة عبر خدمات خارجية"""
        # هذه مجرد محاكاة لأغراض تعليمية
        is_valid = self.generator.validate_card(card_number.replace(' ', ''))
        
        return {
            'valid': is_valid,
            'card_type': self.detect_card_type(card_number),
            'risk_score': random.randint(1, 100),
            'recommendation': 'APPROVE' if is_valid and random.random() > 0.3 else 'REVIEW'
        }
    
    def detect_card_type(self, card_number):
        """كشف نوع البطاقة من الرقم"""
        clean_number = card_number.replace(' ', '')
        first_digit = clean_number[0]
        
        if first_digit == '4':
            return 'VISA'
        elif first_digit == '5':
            return 'MASTERCARD'
        elif first_digit == '3':
            return 'AMEX'
        elif first_digit in ['6', '5']:
            return 'DISCOVER'
        else:
            return 'UNKNOWN'

# تشغيل التحقق الإضافي
validator = CardValidatorPlus()
sample_card = cards[0]['raw_number']
validation_result = validator.validate_external_card(sample_card)

print(f"\n🔍 Sample Validation for {sample_card}:")
print(f"Type: {validation_result['card_type']}")
print(f"Valid: {validation_result['valid']}")
print(f"Risk Score: {validation_result['risk_score']}")
print(f"Recommendation: {validation_result['recommendation']}")