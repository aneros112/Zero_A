import webview
import os

class Api:
    def close(self):
        webview.windows[0].destroy()

def open_window():
    # المسار المطلق لملف HTML
    file_path = os.path.abspath("index.html")
    url = f"file://{file_path}"

    # أبعاد الشاشة
    screen = webview.screens[0]
    screen_width, screen_height = screen.width, screen.height

    # نافذة بحجم 70% من الشاشة
    window = webview.create_window(
        title="⚡ واجهة أنيقة ⚡",
        url=url,
        width=int(screen_width * 0.7),
        height=int(screen_height * 0.7),
        frameless=True,      # بدون حواف النظام
        resizable=False,
        js_api=Api(),
        background_color='#0f0f0f'
    )

    return window

if __name__ == '__main__':
    window = open_window()
    webview.start(debug=True)
