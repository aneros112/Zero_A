import webview
import os

# API للتحكم من HTML
class Api:
    def close(self):
        webview.windows[0].destroy()

def open_window():
    # تحديد المسار المطلق للملف
    file_path = os.path.abspath("index.html")
    url = "file://" + file_path

    # أبعاد الشاشة
    screen = webview.screens[0]
    screen_width, screen_height = screen.width, screen.height

    # إنشاء نافذة نصف حجم الشاشة بدون حواف
    window = webview.create_window(
        title="",
        url=url,
        width=screen_width // 2,
        height=screen_height // 2,
        frameless=True,   # بدون شريط نظام
        resizable=False,
        js_api=Api()      # 👈 هنا تحط API بدل start()
    )

    return window

if __name__ == '__main__':
    window = open_window()
    webview.start()
